COMMENTARY:
Very simple.

MODIFIABLE PARAMETERS: None

DSPN EXPLANATION:
Model of a two-phase job service.
There are two states that loop through exponential transitions - preemption and continuation.
We begin in continuation (allows job service).
That means job service stops and resumes.
Job services themselves are deterministic.
The job services are likewise done in a loop.

MODEL OPTIMAL VALUE PROBLEM:
None.

DATE AND AUTHOR:

16 February 2017
Mario Uhrik

ORIGINAL SPN SOURCE: 

Article: Supplementary Variable Approach Applied to the Transient Analysis of Age-MRSPNs
Authors: Miklos Telek, Andras Horvath
http://ieeexplore.ieee.org/abstract/document/707708/