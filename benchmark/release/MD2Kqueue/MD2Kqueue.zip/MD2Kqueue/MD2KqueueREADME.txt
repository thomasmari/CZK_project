COMMENTARY:
MD2Kqueue.pm fdprism model is redundant for K=2, but also supports K>2.
MD22queue.pm fdprism model is optimised for K=2
They both contain concurrent deterministic transitions.

MODIFIABLE PARAMETERS: K=5

DSPN EXPLANATION:
Two-server queueing system with exponentially distributed arrivals and deterministic service.

MODEL OPTIMAL VALUE PROBLEM:
None.


DATE AND AUTHOR:

26 January 2017
Mario Uhrik

ORIGINAL SPN SOURCE: 

Article: Numerical analysis of deterministic and stochastic Petri net with concurrent deterministic transitions
ISSN: 0166-5316
Author: Christoph Lindemann, Gerald S. Shedler
Pages 565-582 
http://www.sciencedirect.com/science/article/pii/S0166531696900462