COMMENTARY:
Has exponential transitions with rates dependant on markings.
Has no concurrent fixed delay transitions.

MODIFIABLE PARAMETERS: K=20, N=6

DSPN EXPLANATION:
Queueing system with deterministic service and finite buffer.
Arrival process is a "superposition of several identical 2-state MMPPs".

MODEL OPTIMAL VALUE PROBLEM:
None that I noticed.


DATE AND AUTHOR:

10 February 2017
Mario Uhrik

ORIGINAL SPN SOURCE: 

Article: New Results for the Analysis of Deterministic and Stochastic Petri Nets
Author:	Reinhard German
http://ieeexplore.ieee.org/abstract/document/395812/